let timer;
let isPaused = false;
let isBreak = false;
let secondsLeft;

const timerDisplay = document.getElementById('timerDisplay');
const startButton = document.getElementById('startButton');
const pauseButton = document.getElementById('pauseButton');
const resetButton = document.getElementById('resetButton');
const workDurationInput = document.getElementById('workDuration');
const breakDurationInput = document.getElementById('breakDuration');

function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes < 10 ? '0' : ''}${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
}

function startTimer() {
    const workDuration = parseInt(workDurationInput.value) * 60;
    const breakDuration = parseInt(breakDurationInput.value) * 60;

    secondsLeft = isBreak ? breakDuration : workDuration;

    timer = setInterval(() => {
        if (secondsLeft <= 0) {
            isBreak = !isBreak; 
            secondsLeft = isBreak ? breakDuration : workDuration;
            alert(isBreak ? "Break Time!" : "Back to Work!");
        }

        secondsLeft--;
        timerDisplay.textContent = formatTime(secondsLeft);
    }, 1000);
}

function pauseTimer() {
    clearInterval(timer);
    isPaused = true;
}

function resetTimer() {
    clearInterval(timer);
    isPaused = false;
    isBreak = false;
    timerDisplay.textContent = formatTime(parseInt(workDurationInput.value) * 60);
}

startButton.addEventListener('click', () => {
    if (!isPaused) {
        resetTimer();
    }
    startTimer();
    isPaused = false;
});

pauseButton.addEventListener('click', pauseTimer);
resetButton.addEventListener('click', resetTimer);


resetTimer();
